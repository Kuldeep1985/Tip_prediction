def factorial(n):
  """
  This function calculates the factorial of a non-negative integer.

  Args:
    n: The non-negative integer for which to calculate the factorial.

  Returns:
    The factorial of n, or 1 if n is 0.

  Raises:
    ValueError: If n is negative.
  """
  if n < 0:
    raise ValueError("Factorial is not defined for negative numbers.")
  elif n == 0:
    return 1
  else:
    fact = 1
    for i in range(1, n + 1):
      fact *= i
    return fact

# Example usage
number = 5
result = factorial(number)
print(f"The factorial of {number} is {result}")
