function factorial(n) {
    if (n < 0) {
      throw new Error("Factorial is not defined for negative numbers.");
    } else if (n === 0) {
      return 1;
    } else {
      let fact = 1;
      for (let i = 1; i <= n; i++) {
        fact *= i;
      }
      return fact;
    }
  }
  
  const number = 5;
  const result = factorial(number);
  console.log(`The factorial of ${number} is ${result}`);
  